// COMP5578 classroom sample: launcher news resource.
