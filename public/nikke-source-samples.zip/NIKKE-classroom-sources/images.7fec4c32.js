// COMP5578 classroom sample: launcher image resource.
